#!/bin/bash
# One-time setup for TonyPi chess (run on the robot as the pi user):
#     cd /home/pi/TonyPi/Functions && bash chess_setup.sh
# Installs python-chess (needed) and Stockfish (recommended) and checks
# that everything the chess program imports is available.
set -u
echo "== TonyPi chess setup =="

if python3 -c "import chess" 2>/dev/null; then
    echo "python-chess: already installed"
else
    echo "python-chess: installing..."
    python3 -m pip install chess 2>/dev/null || python3 -m pip install --break-system-packages chess || sudo python3 -m pip install chess
fi

found=$(python3 -c "import sys; sys.path.insert(0, '.'); import chess_engine; print(chess_engine.find_stockfish() or '')" 2>/dev/null)
if [ -n "$found" ]; then
    echo "stockfish: already installed ($found)"
else
    echo "stockfish: installing with apt (needs sudo)..."
    if sudo apt-get install -y stockfish; then
        echo "stockfish: installed at /usr/games/stockfish"
    else
        echo "stockfish: apt install failed. The robot will use the built-in engine."
        echo "           You can also download an ARM build from https://stockfishchess.org/download/"
        echo "           and run ChessPlay.py --stockfish /path/to/stockfish"
    fi
fi

echo
echo "== checking imports =="
python3 - <<'PY'
import importlib, sys
ok = True
for mod in ("cv2", "numpy", "yaml", "chess", "chess.engine", "chess.pgn"):
    try:
        importlib.import_module(mod)
        print("  %-13s ok" % mod)
    except Exception as e:
        print("  %-13s MISSING (%s)" % (mod, e)); ok = False
sys.path.insert(0, ".")
try:
    import chess_engine
    p = chess_engine.find_stockfish()
    print("  stockfish     %s" % (p if p else "not found -> built-in engine will be used"))
except Exception as e:
    print("  chess_engine  failed to import: %s" % e); ok = False
sys.exit(0 if ok else 1)
PY
status=$?
echo
if [ $status -eq 0 ]; then
    echo "Setup complete. Start a game with:  python3 ChessPlay.py"
    echo "Test without the robot first with:  python3 chess_selftest.py"
else
    echo "Some dependencies are missing; see above."
fi
exit $status
