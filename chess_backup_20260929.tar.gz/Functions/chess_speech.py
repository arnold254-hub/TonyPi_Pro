#!/usr/bin/python3
# coding=utf8
"""
Spoken output for TonyPi chess.

Sentences are built by joining short pre-recorded wav fragments from
/home/pi/TonyPi/audio/chess (all 16 kHz mono 16-bit) into one temporary
wav, which is then played through the robot speaker with Hiwonder's
`speech.play_audio`, or `aplay` if that helper is not importable.
"""
import os
import wave
import shutil
import tempfile
import subprocess

import numpy as np
import chess

try:
    from speech import speech
    HAVE_SPEECH = True
except ImportError:
    HAVE_SPEECH = False

FRAG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "audio", "chess")
PIECE_WORD = {chess.PAWN: "pawn", chess.KNIGHT: "knight", chess.BISHOP: "bishop",
              chess.ROOK: "rook", chess.QUEEN: "queen", chess.KING: "king"}
GAP_MS = 120
TRIM_LEVEL = 300            # samples below this count as silence when trimming
TRIM_KEEP_MS = 60           # silence kept on each side of a fragment
_missing_reported = set()
_no_player_reported = False


def _frag_path(key):
    return os.path.join(FRAG_DIR, "%s.wav" % key)


def _trim(frames, params):
    """Strip leading/trailing silence from 16-bit PCM frames, keeping a short margin."""
    if params.sampwidth != 2:
        return frames
    data = np.frombuffer(frames, np.int16)
    loud = np.where(np.abs(data) > TRIM_LEVEL)[0]
    if loud.size == 0:
        return frames
    keep = int(params.framerate * params.nchannels * TRIM_KEEP_MS / 1000)
    start = max(0, loud[0] - keep)
    end = min(data.size, loud[-1] + keep)
    return data[start:end].tobytes()


def _join(keys, out_path):
    params = None
    with wave.open(out_path, "wb") as out:
        for key in keys:
            path = _frag_path(key)
            if not os.path.isfile(path):
                if key not in _missing_reported:
                    print("chess_speech: missing fragment %s" % path)
                    _missing_reported.add(key)
                continue
            with wave.open(path, "rb") as f:
                if params is None:
                    params = f.getparams()
                    out.setparams(params)
                    gap = b"\x00" * int(params.framerate * params.nchannels * params.sampwidth * GAP_MS / 1000)
                out.writeframes(_trim(f.readframes(f.getnframes()), params))
                out.writeframes(gap)
    return params is not None


def say(keys, text=None):
    """Speak the fragments in order. `text` is printed so the console mirrors the speaker."""
    if isinstance(keys, str):
        keys = [keys]
    global _no_player_reported
    if text:
        print("Robot: " + text)
    if not HAVE_SPEECH and shutil.which("aplay") is None:
        if not _no_player_reported:
            print("chess_speech: no speaker helper or aplay on this machine; sentences are printed only")
            _no_player_reported = True
        return
    fd, tmp = tempfile.mkstemp(suffix=".wav", prefix="tonypi_chess_")
    os.close(fd)
    try:
        if not _join(keys, tmp):
            return
        if HAVE_SPEECH:
            speech.play_audio(tmp)
        else:
            subprocess.run(["aplay", "-q", tmp], timeout=30,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as e:
        print("chess_speech: playback failed: %s" % e)
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def set_volume(level):
    if HAVE_SPEECH:
        try:
            speech.set_volume(level)
        except Exception:
            pass


def move_fragments(board, move):
    """Fragments describing `move` from `board` (board is BEFORE the move). Returns (keys, text)."""
    keys, words = [], []
    if board.is_castling(move):
        if chess.square_file(move.to_square) > chess.square_file(move.from_square):
            keys.append("castles_kingside"); words.append("I castle king side")
        else:
            keys.append("castles_queenside"); words.append("I castle queen side")
    else:
        piece = board.piece_at(move.from_square)
        frm, to = chess.square_name(move.from_square), chess.square_name(move.to_square)
        keys += ["i_play", PIECE_WORD[piece.piece_type], frm[0], frm[1]]
        words.append("I play %s %s" % (PIECE_WORD[piece.piece_type], frm))
        if board.is_capture(move):
            keys.append("takes"); words.append("takes")
        keys += [to[0], to[1]]
        words.append(to)
        if board.is_en_passant(move):
            keys.append("en_passant"); words.append("en passant")
        if move.promotion:
            keys.append("promotes_to_queen"); words.append("and promotes to a queen")
    after = board.copy()
    after.push(move)
    if after.is_checkmate():
        keys.append("checkmate"); words.append("checkmate")
    elif after.is_check():
        keys.append("check"); words.append("check")
    return keys, " ".join(words)


def announce_move(board, move):
    keys, text = move_fragments(board, move)
    say(keys, text)


if __name__ == "__main__":
    b = chess.Board()
    for san in ["e4", "e5", "Nf3", "Nc6", "Bc4", "Nf6", "Nxe5", "Nxe5", "O-O"]:
        m = b.parse_san(san)
        print(san, "->", move_fragments(b, m))
        b.push(m)
