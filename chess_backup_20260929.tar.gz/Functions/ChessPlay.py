#!/usr/bin/python3
# coding=utf8
"""
ChessPlay: TonyPi plays chess against a person.

How a game goes
    1. Setup (first run only): show the camera the EMPTY board, then the
       full STARTING position. The robot learns where the board is, which
       way round it sits and what an occupied / white / black square looks
       like with your pieces and lighting. Nothing about the pieces' shape
       is assumed, so any set works.
    2. You (white by default) make a move on the board and press Enter.
    3. The robot photographs the board, works out which legal move you
       made, thinks, and announces its reply out loud.
    4. You move the robot's piece for it (a TonyPi cannot lift chess
       pieces), make your own move, press Enter. Repeat.

At the prompt you can also type a move (e2e4 or Nf3) if the camera got it
wrong, 'u' to undo the last pair of moves, or 'q' to quit.

Run on the robot as the pi user (no sudo):
    cd /home/pi/TonyPi/Functions && python3 ChessPlay.py
Options:
    --white          robot plays white and moves first
    --time 2.0       thinking time per move in seconds
    --skill 10       Stockfish skill 0-20 (also picks built-in depth)
    --engine auto    auto = Stockfish if installed else built-in search;
                     stockfish = require Stockfish; builtin = never use it
    --stockfish P    path to a Stockfish binary (default: search PATH and
                     /usr/games, or the STOCKFISH_PATH environment variable)
    --recalibrate    redo the board / empty-board setup
    --no-robot       test on a laptop: no servos, use --camera N or a URL
    --no-camera      no board reading at all: type every move at the prompt
                     (handy for testing the engine on a PC)
Every finished game is saved as PGN in /home/pi/TonyPi/chess_games/.
Requires: python3 -m pip install chess     (recommended: sudo apt install stockfish)
Run chess_setup.sh once to install both, and chess_selftest.py to check the
vision / engine / speech code without a robot.
"""
import os
import sys
import time
import argparse
import datetime
import threading

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "HiwonderSDK"))
sys.path.append(ROOT)

try:
    import chess
    import chess.pgn
except ImportError:
    print("python-chess is missing. Install it with:  python3 -m pip install chess")
    sys.exit(1)

import chess_vision as vision
import chess_engine
import chess_speech as speak

CONFIG_YAML = os.path.join(ROOT, "chess_config.yaml")
REFERENCE_PNG = os.path.join(ROOT, "chess_reference.png")
DEBUG_DIR = os.path.join(ROOT, "chess_debug")
GAMES_DIR = os.path.join(ROOT, "chess_games")

HEAD_PAN = None                 # None = use servo_config centre
HEAD_TILT = 1250                # tilt pulse that points the camera down at the board
FRAMES_TO_AVERAGE = 5
ACCEPT_MISSING = 3              # accept a move if at most this many squares disagree
ACCEPT_MARGIN = 2               # ...and it beats the runner-up by at least this


# ----------------------------------------------------------------- robot hardware (optional)
class Robot:
    def __init__(self, enabled=True):
        self.enabled = enabled
        if not enabled:
            return
        import hiwonder.ros_robot_controller_sdk as rrc
        from hiwonder.Controller import Controller
        import hiwonder.ActionGroupControl as AGC
        import hiwonder.yaml_handle as yaml_handle
        self.AGC = AGC
        self.ctl = Controller(rrc.Board())
        servo_data = yaml_handle.get_yaml_data(yaml_handle.servo_file_path)
        self.pan_center = int(servo_data.get("servo2", 1500))

    def look_at_board(self):
        if not self.enabled:
            return
        self.ctl.set_pwm_servo_pulse(1, HEAD_TILT, 600)
        self.ctl.set_pwm_servo_pulse(2, HEAD_PAN if HEAD_PAN else self.pan_center, 600)
        time.sleep(0.7)

    def gesture(self, name, wait=True):
        if not self.enabled:
            return
        t = threading.Thread(target=self.AGC.runActionGroup, args=(name,), daemon=True)
        t.start()
        if wait:
            t.join()
            self.look_at_board()

    def stand(self):
        if self.enabled:
            self.AGC.runActionGroup("stand_slow")


# ----------------------------------------------------------------- camera
class Cam:
    def __init__(self, source=None, use_robot=True):
        self.cap = None
        self.hw = None
        if source is not None:
            src = int(source) if str(source).isdigit() else source
            self.cap = cv2.VideoCapture(src)
        elif use_robot:
            import hiwonder.yaml_handle as yaml_handle
            import hiwonder.Camera as Camera
            open_once = yaml_handle.get_yaml_data('/boot/camera_setting.yaml')['open_once']
            if open_once:
                self.cap = cv2.VideoCapture('http://127.0.0.1:8080/?action=stream?dummy=param.mjpg')
            else:
                self.hw = Camera.Camera()
                self.hw.camera_open()
        else:
            self.cap = cv2.VideoCapture(0)

    def frame(self):
        if self.hw is not None:
            ret, img = self.hw.read()
        else:
            ret, img = self.cap.read()
        return img if ret else None

    def grab(self, n=FRAMES_TO_AVERAGE):
        """Median of several frames: removes sensor noise and a hand passing by."""
        frames = []
        deadline = time.time() + 5
        while len(frames) < n and time.time() < deadline:
            img = self.frame()
            if img is not None:
                frames.append(img)
                time.sleep(0.05)
        if not frames:
            raise RuntimeError("no image from the camera")
        return np.median(np.stack(frames), axis=0).astype(np.uint8)

    def close(self):
        if self.hw is not None:
            self.hw.camera_close()
        elif self.cap is not None:
            self.cap.release()


# ----------------------------------------------------------------- display / debug
SHOW = bool(os.environ.get("DISPLAY"))


def show(name, img):
    os.makedirs(DEBUG_DIR, exist_ok=True)
    cv2.imwrite(os.path.join(DEBUG_DIR, name + ".jpg"), img)
    if SHOW:
        cv2.imshow(name, img)
        cv2.waitKey(1)


def ask(prompt):
    try:
        return input(prompt).strip()
    except EOFError:
        return "q"


def click_corners(img):
    """Let the user click the 4 board corners in a window. Returns corners or None."""
    if not SHOW:
        return None
    pts = []
    view = img.copy()

    def on_mouse(event, x, y, flags, param):
        if event == cv2.EVENT_LBUTTONDOWN and len(pts) < 4:
            pts.append((x, y))
            cv2.circle(view, (x, y), 5, (0, 0, 255), -1)

    cv2.namedWindow("click corners")
    cv2.setMouseCallback("click corners", on_mouse)
    print("Click the 4 corners of the board (any order). Press Esc to cancel.")
    while len(pts) < 4:
        cv2.imshow("click corners", view)
        if cv2.waitKey(30) == 27:
            cv2.destroyWindow("click corners")
            return None
    cv2.destroyWindow("click corners")
    return vision.order_corners(pts)


def type_corners():
    print("Open chess_debug/camera.jpg, note the pixel coordinates of the 4 board corners,")
    print("and type them as: x,y x,y x,y x,y   (or press Enter to retry auto-detection)")
    txt = ask("> ")
    if not txt:
        return None
    try:
        pts = [tuple(float(v) for v in p.split(",")) for p in txt.split()]
        assert len(pts) == 4
        return vision.order_corners(pts)
    except Exception:
        print("Could not parse that.")
        return None


# ----------------------------------------------------------------- calibration
def calibrate_board(cam):
    """Find the board corners and capture the empty-board reference."""
    while True:
        ask("\nSTEP 1  Put the EMPTY board in front of the robot, then press Enter > ")
        img = cam.grab()
        show("camera", img)
        corners = vision.find_board_corners(img)
        if corners is not None:
            print("Board found automatically.")
        else:
            print("Automatic detection failed.")
            corners = click_corners(img) or type_corners()
            if corners is None:
                continue
        cal = vision.Calibration(corners)
        vision.set_reference(cal, img)
        show("camera", vision.draw_corners(img, corners))
        show("empty_board", vision.draw_grid(cal.reference))
        print("Check chess_debug/empty_board.jpg: the 8x8 grid should line up with the squares.")
        if ask("Is the grid aligned? [Y/n] > ").lower() in ("", "y", "yes"):
            cal.save(CONFIG_YAML, REFERENCE_PNG)
            print("Saved board calibration to %s" % CONFIG_YAML)
            return cal


def learn_pieces(cam, cal):
    """Learn occupancy / colour thresholds and orientation from the starting position."""
    while True:
        ask("\nSTEP 2  Set up ALL pieces in the starting position, then press Enter > ")
        img = cam.grab()
        rep = vision.learn_from_start(cal, img)
        occ, white, warped = vision.observe(cal, img)
        show("start_position", vision.draw_grid(warped, occ, white, chess.Board()))
        n_occ = int(occ.sum())
        n_white = int((occ & white).sum())
        print("Detected %d occupied squares (expect 32), %d white pieces (expect 16)." % (n_occ, n_white))
        print("Occupancy separation %.1f, colour separation %.1f (both should be clearly > 0)."
              % (rep["occupancy_separation"], rep["colour_separation"]))
        good = n_occ == 32 and n_white == 16 and rep["occupancy_separation"] > 0 and rep["colour_separation"] > 0
        if good:
            print("Board orientation: white is at the bottom of chess_debug/start_position.jpg.")
            cal.save(CONFIG_YAML, REFERENCE_PNG)
            return
        print("Detection is not clean. Improve the lighting / avoid shadows and glare, then retry.")
        if ask("Retry? [Y/n] > ").lower() not in ("", "y", "yes"):
            print("Continuing anyway; you can always type moves at the prompt.")
            cal.save(CONFIG_YAML, REFERENCE_PNG)
            return


# ----------------------------------------------------------------- move reading
def read_human_move(cam, cal, board):
    """Photograph the board and infer the human's move. Returns a move or None."""
    img = cam.grab()
    occ, white, warped = vision.observe(cal, img)
    ranked, no_move = vision.infer_move(board, occ, white)
    show("camera", img)
    if not ranked:
        return None
    best, score = ranked[0]
    second = ranked[1][1] if len(ranked) > 1 else -999
    after = board.copy()
    after.push(best)
    max_score = 64 + len(after.piece_map())
    show("last_read", vision.draw_grid(warped, occ, white, after))
    print("Camera: best guess %s (score %d/%d, runner-up %d, no-move %d)"
          % (board.san(best), score, max_score, second, no_move))
    if max_score - score <= ACCEPT_MISSING and score - second >= ACCEPT_MARGIN and score > no_move:
        return best
    print("Not confident. Candidates: " + ", ".join(board.san(m) for m, _ in ranked[:4]))
    return None


def parse_typed_move(board, text):
    for parser in (board.parse_uci, board.parse_san):
        try:
            return parser(text)
        except Exception:
            pass
    return None


def save_pgn(board, robot_color, engine_name, result, started):
    """Write the game to chess_games/<timestamp>.pgn. Returns the path or None."""
    if not board.move_stack:
        return None
    try:
        game = chess.pgn.Game.from_board(board)
        robot_name = "TonyPi (%s)" % engine_name
        game.headers["Event"] = "TonyPi chess"
        game.headers["Site"] = "TonyPi"
        game.headers["Date"] = started.strftime("%Y.%m.%d")
        game.headers["White"] = robot_name if robot_color == chess.WHITE else "Human"
        game.headers["Black"] = robot_name if robot_color == chess.BLACK else "Human"
        game.headers["Result"] = result
        os.makedirs(GAMES_DIR, exist_ok=True)
        path = os.path.join(GAMES_DIR, started.strftime("%Y%m%d_%H%M%S") + ".pgn")
        with open(path, "w", encoding="utf-8") as fp:
            print(game, file=fp, end="\n\n")
        return path
    except Exception as e:
        print("Could not save the PGN: %s" % e)
        return None


# ----------------------------------------------------------------- game
def play(args):
    robot = Robot(enabled=not args.no_robot)
    cam = None if args.no_camera else Cam(args.camera, use_robot=not args.no_robot)
    engine = chess_engine.make_engine(time_limit=args.time, skill=args.skill,
                                      engine=args.engine, path=args.stockfish)
    speak.set_volume(80)
    robot.look_at_board()

    cal = None
    if cam is None:
        print("No camera: type your moves at the prompt (e2e4, Nf3, O-O ...).")
    else:
        cal = None if args.recalibrate else vision.Calibration.load(CONFIG_YAML)
        if cal is None:
            cal = calibrate_board(cam)
        else:
            print("Loaded board calibration from %s (use --recalibrate if the board or camera moved)." % CONFIG_YAML)
        learn_pieces(cam, cal)

    board = chess.Board()
    robot_color = chess.WHITE if args.white else chess.BLACK
    started = datetime.datetime.now()
    result = "*"
    robot.gesture("bow")
    if robot_color == chess.WHITE:
        speak.say("lets_play", "Let's play chess. I am white, so I will start.")
    else:
        speak.say("lets_play", "Let's play chess. Make your move, then press Enter.")

    try:
        while not board.is_game_over(claim_draw=True):
            print("\n" + str(board) + "\n")
            if board.turn == robot_color:
                move = engine.best_move(board)
                if move is None:
                    print("The engine returned no move; stopping.")
                    break
                speak.announce_move(board, move)
                board.push(move)
                if not board.is_game_over(claim_draw=True):
                    speak.say("please_move_my_piece", "Please move my piece for me, then make your move and press Enter.")
                continue

            # human's turn
            text = ask("Your move: press Enter when done (or type a move, 'u' undo, 'q' quit) > ")
            if text.lower() in ("q", "quit", "resign"):
                result = "1-0" if robot_color == chess.WHITE else "0-1"
                speak.say("good_game", "Good game.")
                return
            if text.lower() in ("u", "undo"):
                if len(board.move_stack) >= 2:
                    board.pop(); board.pop()
                    print("Undid the last two moves. Put the pieces back, then continue.")
                else:
                    print("Nothing to undo.")
                continue
            if text:
                move = parse_typed_move(board, text)
                if move is None:
                    print("'%s' is not a legal move here." % text)
                    continue
            elif cam is None:
                print("No camera. Type your move, for example e2e4 or Nf3.")
                continue
            else:
                try:
                    move = read_human_move(cam, cal, board)
                except Exception as e:
                    print("Camera problem: %s" % e)
                    move = None
                if move is None:
                    speak.say("did_not_understand", "I could not read your move. Please type it.")
                    continue
            print("You played %s" % board.san(move))
            board.push(move)

        # game over
        if board.is_game_over(claim_draw=True):
            result = board.result(claim_draw=True)
            print("\n" + str(board) + "\nResult: " + result)
            if board.is_checkmate():
                if board.turn != robot_color:
                    speak.say("i_win", "Checkmate. I win. Good game.")
                    robot.gesture("chest")
                else:
                    speak.say("you_win", "You win. Well played.")
                    robot.gesture("bow")
            else:
                speak.say("draw", "The game is a draw.")
                robot.gesture("bow")
    except KeyboardInterrupt:
        print("\nInterrupted.")
        speak.say("good_game", "Good game.")
    finally:
        pgn = save_pgn(board, robot_color, engine.name, result, started)
        if pgn:
            print("Game saved to %s" % pgn)
        engine.quit()
        if cam is not None:
            cam.close()
        robot.stand()
        if SHOW:
            cv2.destroyAllWindows()


def main():
    ap = argparse.ArgumentParser(description="TonyPi plays chess")
    ap.add_argument("--white", action="store_true", help="robot plays white (moves first)")
    ap.add_argument("--time", type=float, default=2.0, help="thinking time per move, seconds")
    ap.add_argument("--skill", type=int, default=10, help="strength 0-20")
    ap.add_argument("--engine", choices=["auto", "stockfish", "builtin"], default="auto",
                    help="auto: Stockfish if installed, else built-in search (default)")
    ap.add_argument("--stockfish", default=None, metavar="PATH", help="path to the Stockfish binary")
    ap.add_argument("--recalibrate", action="store_true", help="redo board detection")
    ap.add_argument("--no-robot", action="store_true", help="no servos; for testing on a PC")
    ap.add_argument("--no-camera", action="store_true", help="type every move; no board reading")
    ap.add_argument("--camera", default=None, help="camera index or stream URL (default: robot camera)")
    args = ap.parse_args()
    try:
        play(args)
    except RuntimeError as e:
        print("Error: %s" % e)
        sys.exit(1)


if __name__ == "__main__":
    main()
