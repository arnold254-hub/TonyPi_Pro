#!/usr/bin/python3
# coding=utf8
"""
Self-test for TonyPi chess. Needs no robot and no camera.

    python3 chess_selftest.py            # vision + engine + speech + a scripted game
    python3 chess_selftest.py --quick    # skip the scripted game

A chessboard with round "pieces" is drawn in perspective, fed through
chess_vision in all four orientations, and every move of a short game must
be read back correctly. The engine must find a mate in one (Stockfish too,
if it is installed). Every audio fragment the robot can say must exist.
Finally ChessPlay.play() is driven with a fake camera and keyboard.
"""
import os
import sys
import glob
import shutil
import tempfile
import argparse

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

try:
    import chess
except ImportError:
    print("python-chess is missing. Install it with:  python3 -m pip install chess")
    sys.exit(1)

import chess_vision as vision
import chess_engine
import chess_speech as speak

FAILURES = []


def check(cond, msg):
    print(("  ok    " if cond else "  FAIL  ") + msg)
    if not cond:
        FAILURES.append(msg)


# ---------------------------------------------------------------- synthetic board
def render(board, rotation=0, noise=6, seed=0):
    """Draw `board` (or an empty board if None) in perspective in a 640x480 frame."""
    sq = 60
    flat = np.zeros((8 * sq, 8 * sq, 3), np.uint8)
    for f in range(8):
        for r in range(8):
            col = (205, 215, 225) if (f + r) % 2 else (60, 90, 120)
            x0, y0 = f * sq, (7 - r) * sq
            cv2.rectangle(flat, (x0, y0), (x0 + sq - 1, y0 + sq - 1), col, -1)
    if board is not None:
        for s, p in board.piece_map().items():
            cx = chess.square_file(s) * sq + sq // 2
            cy = (7 - chess.square_rank(s)) * sq + sq // 2
            white = p.color == chess.WHITE
            cv2.circle(flat, (cx, cy), 18, (235, 235, 235) if white else (25, 25, 25), -1)
            cv2.circle(flat, (cx, cy), 18, (0, 0, 0) if white else (90, 90, 90), 2)
    flat = np.ascontiguousarray(np.rot90(flat, rotation))
    src = np.float32([[0, 0], [479, 0], [479, 479], [0, 479]])
    dst = np.float32([[150, 60], [500, 60], [560, 430], [90, 430]])
    M = cv2.getPerspectiveTransform(src, dst)
    bg = np.full((480, 640, 3), (170, 150, 140), np.uint8)
    img = cv2.warpPerspective(flat, M, (640, 480), dst=bg, borderMode=cv2.BORDER_TRANSPARENT)
    rng = np.random.default_rng(seed)
    img = img.astype(np.int16) + rng.integers(-noise, noise + 1, img.shape, dtype=np.int16)
    return np.clip(img, 0, 255).astype(np.uint8)


GAME = ["e4", "c5", "Nf3", "d6", "d4", "cxd4", "Nxd4", "Nf6", "Nc3", "a6",
        "Be3", "e5", "Nb3", "Be6", "f3", "Be7", "Qd2", "O-O", "O-O-O", "Nbd7"]


def calibrate(rot):
    empty = render(None, rot)
    corners = vision.find_board_corners(empty)
    if corners is None:
        return None, None
    cal = vision.Calibration(corners)
    vision.set_reference(cal, empty)
    rep = vision.learn_from_start(cal, render(chess.Board(), rot, seed=1))
    return cal, rep


def play_through(cal, rot, seed0=10):
    """Return the number of misread moves when GAME is played on a synthetic board."""
    b = chess.Board()
    wrong = 0
    for i, san in enumerate(GAME):
        m = b.parse_san(san)
        after = b.copy()
        after.push(m)
        occ, white, _ = vision.observe(cal, render(after, rot, seed=seed0 + i))
        ranked, _ = vision.infer_move(b, occ, white)
        if ranked[0][0] != m:
            wrong += 1
        b.push(m)
    return wrong


def test_vision():
    print("vision")
    for rot in range(4):
        cal, rep = calibrate(rot)
        if cal is None:
            check(False, "rotation %d: board corners not found" % rot)
            continue
        occ, white, _ = vision.observe(cal, render(chess.Board(), rot, seed=2))
        check(occ.sum() == 32 and (occ & white).sum() == 16,
              "rotation %d: start position read as %d occupied / %d white (sep %.1f / %.1f)"
              % (rot, occ.sum(), (occ & white).sum(), rep["occupancy_separation"], rep["colour_separation"]))
        wrong = play_through(cal, rot)
        check(wrong == 0, "rotation %d: %d of %d moves misread" % (rot, wrong, len(GAME)))

    # save / reload the calibration and learn the pieces again (second run of ChessPlay)
    tmp = tempfile.mkdtemp(prefix="tonypi_chess_")
    try:
        cal, _ = calibrate(1)
        cal.save(os.path.join(tmp, "c.yaml"), os.path.join(tmp, "r.png"))
        cal2 = vision.Calibration.load(os.path.join(tmp, "c.yaml"))
        check(cal2 is not None and cal2.rotation == cal.rotation, "calibration saved and reloaded")
        vision.learn_from_start(cal2, render(chess.Board(), 1, seed=5))
        occ, white, _ = vision.observe(cal2, render(chess.Board(), 1, seed=6))
        check(occ.sum() == 32 and (occ & white).sum() == 16 and play_through(cal2, 1, 40) == 0,
              "re-learning pieces from a reloaded calibration still reads the board")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    # promotion: the four promotion pieces look the same, the queen must win clearly
    cal, _ = calibrate(0)
    b = chess.Board("4k3/1P6/8/8/8/8/8/4K3 w - - 0 1")
    after = b.copy()
    after.push_san("b8=Q")
    occ, white, _ = vision.observe(cal, render(after, 0, seed=3))
    ranked, _ = vision.infer_move(b, occ, white)
    check(ranked[0][0] == after.move_stack[-1] and ranked[0][1] - ranked[1][1] >= 2,
          "promotion read as %s" % b.san(ranked[0][0]))


# ---------------------------------------------------------------- engine
MATE_IN_ONE = "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 0 4"


def test_engine():
    print("engine")
    eng = chess_engine.make_engine(time_limit=1.5, engine="builtin")
    b = chess.Board(MATE_IN_ONE)
    m = eng.best_move(b)
    check(b.is_checkmate() is False and b.san(m) == "Qxf7#", "built-in engine finds mate in one (%s)" % b.san(m))
    eng.quit()
    path = chess_engine.find_stockfish()
    if path:
        try:
            eng = chess_engine.make_engine(time_limit=1.0, engine="stockfish")
            m = eng.best_move(chess.Board(MATE_IN_ONE))
            check(b.san(m) == "Qxf7#", "%s finds mate in one (%s)" % (eng.name, b.san(m)))
            eng.quit()
        except Exception as e:
            check(False, "Stockfish at %s failed: %s" % (path, e))
    else:
        print("  info  Stockfish not installed; the robot will use the built-in engine (sudo apt install stockfish)")


# ---------------------------------------------------------------- speech
SENTENCES = ["lets_play", "please_move_my_piece", "did_not_understand", "good_game", "i_win", "you_win", "draw"]


def test_speech():
    print("speech")
    b = chess.Board()
    keys_seen = set(SENTENCES)
    for san in ["e4", "e5", "Nf3", "Nc6", "Bc4", "Nf6", "Nxe5", "Nxe5", "O-O"]:
        m = b.parse_san(san)
        keys, _ = speak.move_fragments(b, m)
        keys_seen.update(keys)
        b.push(m)
    b = chess.Board(MATE_IN_ONE)
    keys_seen.update(speak.move_fragments(b, b.parse_san("Qxf7#"))[0])
    keys_seen.update(["a", "b", "c", "d", "e", "f", "g", "h", "1", "2", "3", "4", "5", "6", "7", "8",
                      "pawn", "knight", "bishop", "rook", "queen", "king", "takes", "check", "checkmate",
                      "castles_kingside", "castles_queenside", "en_passant", "promotes_to_queen"])
    missing = sorted(k for k in keys_seen if not os.path.isfile(speak._frag_path(k)))
    check(not missing, "all %d audio fragments present in %s%s"
          % (len(keys_seen), speak.FRAG_DIR, (" (missing: %s)" % ", ".join(missing)) if missing else ""))
    check("checkmate" in speak.move_fragments(b, b.parse_san("Qxf7#"))[0], "mate is announced")


# ---------------------------------------------------------------- scripted game
def test_game():
    """Drive ChessPlay.play() with a fake camera and keyboard: calibrate, then a few moves."""
    print("scripted game (ChessPlay.play with a fake camera)")
    import ChessPlay as CP
    tmp = tempfile.mkdtemp(prefix="tonypi_chess_")
    CP.CONFIG_YAML = os.path.join(tmp, "chess_config.yaml")
    CP.REFERENCE_PNG = os.path.join(tmp, "chess_reference.png")
    CP.DEBUG_DIR = os.path.join(tmp, "chess_debug")
    CP.GAMES_DIR = os.path.join(tmp, "chess_games")
    CP.SHOW = False
    rot = 2
    physical = chess.Board()
    state = {"grabs": 0, "plies": 0}
    spoken = []

    class FakeCam:
        def __init__(self, *a, **k):
            pass

        def grab(self, n=1):
            state["grabs"] += 1
            return render(None if state["grabs"] == 1 else physical, rot, seed=state["grabs"])

        def close(self):
            pass

    def fake_say(keys, text=None):
        spoken.append(text or "")

    def fake_announce(board, move):
        spoken.append(speak.move_fragments(board, move)[1])
        physical.push(move)                       # the human moves the robot's piece

    keyboard = iter(["", "y", ""])                # STEP 1, grid aligned, STEP 2

    def fake_ask(prompt):
        try:
            return next(keyboard)
        except StopIteration:
            pass
        state["plies"] += 1
        if state["plies"] == 1:
            return ""                             # Enter without moving: must be rejected
        if state["plies"] == 2:
            physical.push_san("e4")
            return "e4"                           # typed move
        if state["plies"] > 6:
            return "q"
        m = next(iter(physical.legal_moves))
        physical.push(m)
        return ""                                 # move made on the board, Enter

    saved = (CP.Cam, CP.ask, speak.say, speak.announce_move)
    CP.Cam, CP.ask, speak.say, speak.announce_move = FakeCam, fake_ask, fake_say, fake_announce
    try:
        args = argparse.Namespace(white=False, time=0.3, skill=5, recalibrate=True, no_robot=True,
                                  camera=None, no_camera=False, engine="auto", stockfish=None)
        CP.play(args)
        check(any("could not read" in t for t in spoken), "an unchanged board is reported as unreadable")
        check(len(physical.move_stack) == 10, "5 human and 5 robot moves were played (%d)" % len(physical.move_stack))
        check(os.path.isfile(CP.CONFIG_YAML), "calibration saved")
        pgns = glob.glob(os.path.join(CP.GAMES_DIR, "*.pgn"))
        check(len(pgns) == 1 and "1. e4" in open(pgns[0]).read(), "game saved as PGN")
    except Exception as e:
        check(False, "ChessPlay.play raised %r" % e)
    finally:
        CP.Cam, CP.ask, speak.say, speak.announce_move = saved
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="skip the scripted game")
    opts = ap.parse_args()
    test_vision()
    test_engine()
    test_speech()
    if not opts.quick:
        test_game()
    print()
    if FAILURES:
        print("%d check(s) FAILED" % len(FAILURES))
        sys.exit(1)
    print("ALL OK")
