# TonyPi plays chess

TonyPi watches a real chessboard with its camera, works out the move you
made, thinks with **Stockfish** (or a built-in search when Stockfish is not
installed) and announces its reply through the speaker. Because the robot
cannot lift chess pieces, you move its piece for it.

## Files

| File | Purpose |
|------|---------|
| `ChessPlay.py` | The program you run. Calibration, game loop, robot gestures. |
| `chess_engine.py` | Stockfish over UCI, with a pure-Python alpha-beta fallback. |
| `chess_vision.py` | Finds the board, warps it flat, detects occupied / white / black squares, infers the human's move. |
| `chess_speech.py` | Builds spoken sentences from the wav fragments in `../audio/chess/`. |
| `chess_setup.sh` | One-time installer for python-chess and Stockfish on the robot. |
| `chess_selftest.py` | Tests vision, engine and speech on any PC using a synthetic board image. |

Generated at runtime (in `/home/pi/TonyPi/`): `chess_config.yaml` and
`chess_reference.png` (board calibration), `chess_debug/*.jpg` (what the
camera saw, useful when a move is misread) and `chess_games/*.pgn` (every
finished game).

## Install (once, on the robot)

```bash
cd /home/pi/TonyPi/Functions
bash chess_setup.sh          # python-chess + sudo apt install stockfish
python3 chess_selftest.py    # everything should print OK
```

## Play

```bash
cd /home/pi/TonyPi/Functions
python3 ChessPlay.py                       # you are white, robot is black
python3 ChessPlay.py --white               # robot plays white and starts
python3 ChessPlay.py --skill 3 --time 1    # easier and faster opponent
python3 ChessPlay.py --engine stockfish    # insist on Stockfish (error if missing)
python3 ChessPlay.py --recalibrate         # board or camera has moved
```

First run only:

1. Put the **empty** board in front of the robot, press Enter. The board
   is found automatically; if not, click its 4 corners in the window (or type
   the pixel coordinates read from `chess_debug/camera.jpg`).
2. Set up **all** pieces in the starting position, press Enter. The robot
   learns what occupied / white / black squares look like under your
   lighting and which way round the board is. It should report 32 occupied
   squares and 16 white pieces.

Then every turn: make your move on the board and press Enter. The robot
reads the board, announces its move, and you move its piece for it.

At the prompt you can also type:

- a move such as `e2e4`, `Nf3` or `O-O` if the camera read it wrong,
- `u` to undo the last pair of moves (put the pieces back first),
- `q` to resign and quit.

## Engine

Stockfish is used automatically when it can be found: on PATH,
`/usr/games/stockfish` (where `apt install stockfish` puts it), a few other
common directories, or the path given by `--stockfish` / the
`STOCKFISH_PATH` environment variable. It runs with 2 threads and a 64 MB
hash to leave CPU for the camera, and the `--skill` value (0-20) maps to
Stockfish's *Skill Level*. If Stockfish crashes mid-game the program
switches to the built-in engine and the game continues.

## Tips for reliable move reading

- Even, diffuse light; avoid shadows across the board and glare on pieces.
- Keep your hand out of the picture when you press Enter.
- Recalibrate (`--recalibrate`) after moving the board, the robot or the light.
- Run with `--no-robot --camera 0` on a laptop with a webcam to try it out.
