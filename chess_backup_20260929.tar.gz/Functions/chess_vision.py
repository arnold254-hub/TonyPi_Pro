#!/usr/bin/python3
# coding=utf8
"""
Board vision for TonyPi chess. Pure OpenCV + numpy, no robot hardware.

The approach is deliberately independent of what the pieces look like:
  * The board is located once (auto-detected or by clicking its 4 corners)
    and warped to a flat 8x8 image.
  * An EMPTY board is captured as a reference. A square is "occupied" when
    it differs enough from the reference.
  * The STARTING position is captured to learn two thresholds under the
    current lighting: how much difference means "occupied", and how bright
    a piece must be to count as white. It also works out which way round
    the board is, so the pieces' colour tells us where white sits.
  * During play, which piece stands where is tracked by the game logic
    (python-chess); the camera only needs to see occupied / empty and
    light / dark. The opponent's move is the legal move that best explains
    what changed on the board.
"""
import os
import cv2
import numpy as np
import chess

WARP_SIZE = 400                 # warped board is WARP_SIZE x WARP_SIZE px
SQ = WARP_SIZE // 8
INNER = 0.30                    # fraction of a square trimmed from each side when sampling


# ---------------------------------------------------------------- geometry
def order_corners(pts):
    """Return 4 points ordered top-left, top-right, bottom-right, bottom-left."""
    pts = np.array(pts, dtype=np.float32).reshape(4, 2)
    s = pts.sum(axis=1)
    d = np.diff(pts, axis=1).reshape(-1)
    tl, br = pts[np.argmin(s)], pts[np.argmax(s)]
    tr, bl = pts[np.argmin(d)], pts[np.argmax(d)]
    return np.array([tl, tr, br, bl], dtype=np.float32)


def rotate_corners(corners, k):
    """Rotate the corner order so the warped image turns by 90*k degrees."""
    c = list(corners)
    k %= 4
    return np.array(c[k:] + c[:k], dtype=np.float32)


def find_board_corners(img):
    """Auto-detect an EMPTY chessboard. Returns 4 outer corners (TL,TR,BR,BL) or None."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    pts = None
    if hasattr(cv2, "findChessboardCornersSB"):          # robust detector, OpenCV >= 4.0
        found, pts = cv2.findChessboardCornersSB(gray, (7, 7), flags=cv2.CALIB_CB_EXHAUSTIVE | cv2.CALIB_CB_ACCURACY)
        if not found:
            pts = None
    if pts is None:                                        # classic detector as a backup
        flags = cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE
        found, pts = cv2.findChessboardCorners(cv2.GaussianBlur(gray, (3, 3), 0), (7, 7), flags=flags)
        if not found:
            return None
        pts = cv2.cornerSubPix(gray, pts, (5, 5), (-1, -1),
                               (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.01))
    g = pts.reshape(7, 7, 2)
    # extrapolate one square beyond the inner-corner grid along the diagonals
    tl = 2 * g[0, 0] - g[1, 1]
    tr = 2 * g[0, 6] - g[1, 5]
    br = 2 * g[6, 6] - g[5, 5]
    bl = 2 * g[6, 0] - g[5, 1]
    return order_corners([tl, tr, br, bl])


def warp_board(img, corners):
    dst = np.array([[0, 0], [WARP_SIZE - 1, 0], [WARP_SIZE - 1, WARP_SIZE - 1], [0, WARP_SIZE - 1]], np.float32)
    M = cv2.getPerspectiveTransform(np.array(corners, np.float32), dst)
    return cv2.warpPerspective(img, M, (WARP_SIZE, WARP_SIZE))


def square_rect(square):
    """Pixel rect (x0,y0,x1,y1) of a chess square in the warped image (a8 top-left, h1 bottom-right)."""
    f, r = chess.square_file(square), chess.square_rank(square)
    x0, y0 = f * SQ, (7 - r) * SQ
    m = int(SQ * INNER)
    return x0 + m, y0 + m, x0 + SQ - m, y0 + SQ - m


# ---------------------------------------------------------------- measurements
def measure(warped, reference):
    """
    For all 64 squares return (diff, brightness):
      diff       mean abs difference to the empty reference (0-255)
      brightness mean grey level of the pixels that differ (the piece), 0-255
    """
    g = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY).astype(np.int16)
    r = cv2.cvtColor(reference, cv2.COLOR_BGR2GRAY).astype(np.int16)
    absdiff = np.abs(g - r)
    diff = np.zeros(64, np.float32)
    bright = np.zeros(64, np.float32)
    for sq in chess.SQUARES:
        x0, y0, x1, y1 = square_rect(sq)
        d = absdiff[y0:y1, x0:x1]
        diff[sq] = d.mean()
        mask = d > max(15, d.mean())
        px = g[y0:y1, x0:x1][mask]
        bright[sq] = px.mean() if px.size > 20 else g[y0:y1, x0:x1].mean()
    return diff, bright


START_OCC = np.zeros(64, bool)
for _sq in chess.SQUARES:
    START_OCC[_sq] = chess.square_rank(_sq) in (0, 1, 6, 7)
START_WHITE = np.zeros(64, bool)
for _sq in chess.SQUARES:
    START_WHITE[_sq] = chess.square_rank(_sq) in (0, 1)


class Calibration:
    """Everything needed to read the board: corners, orientation, thresholds, reference."""

    def __init__(self, corners=None, rotation=0, occ_threshold=None, white_threshold=None, reference=None):
        self.corners = None if corners is None else np.array(corners, np.float32)
        self.rotation = int(rotation)
        self.occ_threshold = occ_threshold
        self.white_threshold = white_threshold
        self.reference = reference          # warped empty board (BGR), already rotated

    @property
    def ready(self):
        return (self.corners is not None and self.reference is not None
                and self.occ_threshold is not None and self.white_threshold is not None)

    def oriented_corners(self):
        return rotate_corners(self.corners, self.rotation)

    def warp(self, img):
        return warp_board(img, self.oriented_corners())

    # -- persistence
    def save(self, yaml_path, reference_path):
        import yaml
        data = {
            "corners": [[float(x), float(y)] for x, y in self.corners],
            "rotation": self.rotation,
            "occ_threshold": None if self.occ_threshold is None else float(self.occ_threshold),
            "white_threshold": None if self.white_threshold is None else float(self.white_threshold),
            "reference": reference_path,
        }
        with open(yaml_path, "w", encoding="utf-8") as fp:
            yaml.dump(data, fp)
        if self.reference is not None:
            cv2.imwrite(reference_path, self.reference)

    @classmethod
    def load(cls, yaml_path):
        import yaml
        if not os.path.isfile(yaml_path):
            return None
        with open(yaml_path, "r", encoding="utf-8") as fp:
            data = yaml.load(fp, Loader=yaml.FullLoader) or {}
        ref = cv2.imread(data.get("reference", "")) if data.get("reference") else None
        if data.get("corners") is None or ref is None:
            return None
        return cls(data["corners"], data.get("rotation", 0), data.get("occ_threshold"),
                   data.get("white_threshold"), ref)


def set_reference(cal, empty_img):
    """Store the warped empty board. Must be called before learning thresholds."""
    cal.reference = warp_board(empty_img, rotate_corners(cal.corners, 0))
    cal.rotation = 0


def learn_from_start(cal, start_img):
    """
    Given the image of the starting position, work out the board orientation
    and the occupancy / colour thresholds. Returns a quality report dict.
    """
    # cal.reference is stored already rotated by cal.rotation (so a reloaded
    # calibration can be used directly); undo that to get the rotation-0 view.
    raw_ref = np.rot90(cal.reference, cal.rotation) if cal.rotation else cal.reference
    best = None
    for k in range(4):
        corners = rotate_corners(cal.corners, k)
        warped = warp_board(start_img, corners)
        ref = np.rot90(raw_ref, -k) if k else raw_ref       # rotate the reference the same way
        diff, bright = measure(warped, ref)
        occ_d, emp_d = diff[START_OCC], diff[~START_OCC]
        separation = occ_d.min() - emp_d.max()               # >0 means occupancy is cleanly separable
        white_b = bright[START_WHITE].mean()
        black_b = bright[START_OCC & ~START_WHITE].mean()
        score = separation + 0.5 * (white_b - black_b)       # white must be at the bottom
        if best is None or score > best[0]:
            best = (score, k, diff, bright, ref, separation, white_b, black_b)
    score, k, diff, bright, ref, separation, white_b, black_b = best
    cal.rotation = k
    cal.reference = np.ascontiguousarray(ref)
    occ_sorted = np.sort(diff)
    cal.occ_threshold = float((occ_sorted[31] + occ_sorted[32]) / 2)
    wb = np.sort(bright[START_WHITE])
    bb = np.sort(bright[START_OCC & ~START_WHITE])
    cal.white_threshold = float((wb.min() + bb.max()) / 2)
    return {
        "rotation": k,
        "occupancy_separation": float(separation),
        "occ_threshold": cal.occ_threshold,
        "white_mean": float(white_b),
        "black_mean": float(black_b),
        "white_threshold": cal.white_threshold,
        "colour_separation": float(wb.min() - bb.max()),
    }


def observe(cal, img):
    """Read the board: returns (occupied[64] bool, is_white[64] bool, warped image)."""
    warped = cal.warp(img)
    diff, bright = measure(warped, cal.reference)
    occ = diff > cal.occ_threshold
    white = bright > cal.white_threshold
    return occ, white, warped


def expected_state(board):
    occ = np.zeros(64, bool)
    white = np.zeros(64, bool)
    for sq, piece in board.piece_map().items():
        occ[sq] = True
        white[sq] = piece.color == chess.WHITE
    return occ, white


def state_score(occ, white, exp_occ, exp_white):
    """How well an observation matches an expected position (max 128)."""
    occ_match = (occ == exp_occ)
    colour_match = occ_match & exp_occ & (white == exp_white)
    return int(occ_match.sum() + colour_match.sum())


def infer_move(board, occ, white):
    """
    Rank the legal moves by how well the board would look after each one.
    Returns a list of (move, score) sorted best first, plus the score of
    'no move happened' for comparison.
    """
    ranked = []
    for m in board.legal_moves:
        # All four promotions look identical to the camera; assume a queen.
        # An underpromotion can always be typed at the prompt.
        if m.promotion and m.promotion != chess.QUEEN:
            continue
        board.push(m)
        eo, ew = expected_state(board)
        board.pop()
        ranked.append((m, state_score(occ, white, eo, ew)))
    ranked.sort(key=lambda t: -t[1])
    eo, ew = expected_state(board)
    return ranked, state_score(occ, white, eo, ew)


# ---------------------------------------------------------------- drawing helpers
def draw_grid(warped, occ=None, white=None, board=None):
    out = warped.copy()
    for sq in chess.SQUARES:
        f, r = chess.square_file(sq), chess.square_rank(sq)
        x0, y0 = f * SQ, (7 - r) * SQ
        cv2.rectangle(out, (x0, y0), (x0 + SQ - 1, y0 + SQ - 1), (0, 200, 255), 1)
        cv2.putText(out, chess.square_name(sq), (x0 + 2, y0 + 12), cv2.FONT_HERSHEY_PLAIN, 0.8, (0, 200, 255), 1)
        if occ is not None and occ[sq]:
            colour = (255, 255, 255) if (white is not None and white[sq]) else (40, 40, 40)
            cv2.circle(out, (x0 + SQ // 2, y0 + SQ // 2), SQ // 4, colour, 2)
        if board is not None:
            p = board.piece_at(sq)
            if p:
                cv2.putText(out, p.symbol(), (x0 + SQ // 2 - 5, y0 + SQ - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    return out


def draw_corners(img, corners):
    out = img.copy()
    pts = np.array(corners, np.int32).reshape(-1, 1, 2)
    cv2.polylines(out, [pts], True, (0, 255, 0), 2)
    for i, (x, y) in enumerate(np.array(corners).reshape(4, 2)):
        cv2.circle(out, (int(x), int(y)), 5, (0, 0, 255), -1)
        cv2.putText(out, str(i), (int(x) + 6, int(y) - 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
    return out
